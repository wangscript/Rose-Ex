package com.renren.fenqi.application.web.controllers.constant;

public class Constant {
	public static final String UPLOAD_PATH = "/data/resin/workspace/upload/";
	public static final String DOWNLOAD_PATH = "/data/resin/workspace/upload/";
	public static final String DOWNLOAD_ERROR = "/data/resin/workspace/upload/error";
}
