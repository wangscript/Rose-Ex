package net.paoding.rose.jade.tnx;

import net.paoding.rose.scanning.context.RoseAppContext;

public class Test {
	public static void main(String[] args) {
		RoseAppContext c = new RoseAppContext();
		
	}
}
