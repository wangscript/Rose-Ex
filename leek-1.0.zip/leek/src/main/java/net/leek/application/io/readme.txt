用途：
1、IO处理
2、Ftp处理
3、SFtp处理
4、文件处理
5、Excel与数据库处理