加密包

jar:
commons-codec-1.7.jar //apache的 提供base64转码